//
//  ViewControllerCursos.swift
//  appProyecto
//
//  Created by Alessandro Tolentino Hernandez on 31/10/22.
//

import UIKit

class ViewControllerCursos: UIViewController {
    
    
    @IBOutlet weak var tlNombre: UILabel!
    
    var nombre: String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tlNombre.text = nombre
    }
    


    // MARK: - Navigation



}
