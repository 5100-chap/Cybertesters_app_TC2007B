//
//  ViewControllerCorreo.swift
//  appProyecto
//
//  Created by Alessandro Tolentino Hernandez on 17/10/22.
//

import UIKit

class ViewControllerCorreo: UIViewController {

    @IBOutlet weak var tfMat: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    
    @IBAction func botonRegresar(_ sender: UIButton) {
            dismiss(animated: true)
    }
    
    
    
    
    /*
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        if identifier == "siguiente"{
            if tfMat.text == "" {
                let alerta = UIAlertController(title: "Error", message: "No se introdujo un correo/matricula", preferredStyle: .alert)
                let accion = UIAlertAction(title: "Okay", style: .cancel)
                alerta.addAction(accion)
                present(alerta, animated: true)
                return false
            }
        }
        return true
    }
    */
    
    
    
    
    
    
    
}
