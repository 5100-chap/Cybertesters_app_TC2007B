//
//  ViewControllerCorreo.swift
//  appProyecto
//
//  Created by Alessandro Tolentino Hernandez on 17/10/22.
//

import UIKit
import Firebase

class ViewControllerCorreo: UIViewController {
    var db = Firestore.firestore()
    var band : Bool?
    var mat : String?

    
    @IBOutlet weak var tfCorreo: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    @IBAction func botonRegresar(_ sender: UIButton) {
        dismiss(animated: true)
    }
    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        if identifier == "siguiente"{
            
            if tfCorreo.text == "" {
                let alerta = UIAlertController(title: "Error", message: "No se introdujo un correo/matricula", preferredStyle: .alert)
                let accion = UIAlertAction(title: "Okay", style: .cancel)
                alerta.addAction(accion)
                present(alerta, animated: true)
                return false
                
            } else {
                db.collection("alumno").whereField("matricula", isEqualTo: tfCorreo.text)
                    .getDocuments() { (querySnapshot, err) in
                        if let err = err {
                            print("Error getting documents: \(err)")
                        } else {
                            if(querySnapshot!.documents.isEmpty){
                                self.band = true
                                
                            } else {
                                self.band = false
                                
                                let data = querySnapshot!.documents[0].data()
                        
                                self.mat = data["matricula"] as! String
                                //print(querySnapshot!.documents[0].data())
                            }

                        }
                }
            }

            if self.band == true{
                let alerta = UIAlertController(title: "Error", message: "No se encontró una cuenta registrada con la informacion proporcionada", preferredStyle: .alert)
                let accion = UIAlertAction(title: "Okay", style: .cancel)
                alerta.addAction(accion)
                present(alerta, animated: true)
                return false
            } else if self.band == false{
                //print(self.mat!)
                return true
            }
        }
        return false
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "siguiente"{
            let viewEditar = segue.destination as! ViewControllerContra
            
            viewEditar.matricula = self.mat!
            
        }
    }
    
    
    
}
