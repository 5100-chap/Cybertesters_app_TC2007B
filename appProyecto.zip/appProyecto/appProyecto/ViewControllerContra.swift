//
//  ViewControllerContra.swift
//  appProyecto
//
//  Created by Alessandro Tolentino Hernandez on 17/10/22.
//

import UIKit

class ViewControllerContra: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    
    // MARK: - Navigation

     @IBAction func BotonRegresar(_ sender: UIButton) {
         dismiss(animated: true)
         
     }
     

}
