//
//  ViewControllerCursos.swift
//  appProyecto
//
//  Created by Alessandro Tolentino Hernandez on 31/10/22.
//

import UIKit

class ViewControllerCursos: UIViewController {
    
    let defaults = UserDefaults.standard
    var matricula: String?
    
    @IBOutlet weak var tlNombre: UILabel!
    
    var nombre: String!
    
    override func viewDidLoad() {
        matricula = defaults.string(forKey: "matricula")!
        super.viewDidLoad()
        tlNombre.text = matricula
    }
    


    // MARK: - Navigation



}
