//
//  ViewControllerAlumnos.swift
//  appProyecto
//
//  Created by Alessandro Tolentino Hernandez on 11/11/22.
//

import UIKit
import Firebase

class ViewControllerAlumnos: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var db = Firestore.firestore()
    let defaults = UserDefaults.standard
    
    var nomina: String?

    var codigo: String?
    var grupoId: String = "prueba"
    
    var listaAlumnos = [Alumno]()
    
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var tlNombre: UILabel!
    
    @IBOutlet weak var tlTexto: UILabel!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        tlTexto.text = "Alumnos del taller " + codigo! + " Grupo " + grupoId
        
        getCoordinador2()
        getAlumnos()

    }
    
    
    func getCoordinador2(){
        nomina = defaults.string(forKey: "nomina")!
        
        db.collection("coordinador").whereField("nomina", isEqualTo: nomina!)
        .getDocuments() { QuerySnapshot, error in
            if let error = error{
                print(error.localizedDescription)

            } else {
                for document in QuerySnapshot!.documents{
                    let data = document.data()
                    
                    let nombre : String = data["nombre"] as! String
                    
                    self.tlNombre.text = "Coordinador: " + nombre
                }
            }
        }
    }
    
    
    func getAlumnos(){
        var arrAlumnos = [Alumno]()
        
        db.collection("alumno-taller").whereField("codigoTaller", isEqualTo: codigo!)
            .whereField("grupoId",isEqualTo: grupoId)
            .getDocuments() { (querySnapshot, err) in
                if let err = err {
                    print("Error getting documents: \(err)")
                } else {
                    for document in querySnapshot!.documents {
                        let data = document.data()
                        let ident = document.documentID
                        let matricula = data["matricula"] as! String
                        
                        
                        let unAlumno = Alumno(ident: ident, matricula: matricula, nombre: "", correoInstitucional: "", password: "", campus: "")
                        arrAlumnos.append(unAlumno)
                        
                    }
                    self.listaAlumnos = arrAlumnos
                    self.tableView.reloadData()
                }
                
            }
    }
        
        //MARK: - Métodos de data source
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return listaAlumnos.count
        }
        
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let celda = tableView.dequeueReusableCell(withIdentifier: "celda")!
            celda.textLabel?.text = listaAlumnos[indexPath.row].matricula
            celda.imageView?.image = UIImage(named:"user")
    
            return celda
        }
    
    

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "detalle"{
            let vistaAlumno = segue.destination as! ViewControllerDetalleAlumno
            let indice = tableView.indexPathForSelectedRow!
            
            vistaAlumno.matricula = listaAlumnos[indice.row].matricula
        } else if segue.identifier == "add" {
            let vistaAdd = segue.destination as! ViewControllerAddAlumno
            vistaAdd.codigo = codigo
            vistaAdd.grupoId = grupoId
            
        }
        
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        getAlumnos()
    }
    
    
}
