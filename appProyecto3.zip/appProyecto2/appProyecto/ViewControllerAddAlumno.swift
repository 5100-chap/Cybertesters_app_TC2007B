//
//  ViewControllerAddAlumno.swift
//  appProyecto
//
//  Created by Alessandro Tolentino Hernandez on 14/11/22.
//

import UIKit
import Firebase

class ViewControllerAddAlumno: UIViewController {
    var db = Firestore.firestore()
    let defaults = UserDefaults.standard
    var codigo: String?
    var grupoId: String?
    
    
    
    
    @IBOutlet weak var tfMatricula: UITextField!
    
    @IBOutlet weak var tfStatus: UITextField!
    
    @IBOutlet weak var tfPeriodo: UITextField!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    @IBAction func AñadirAlumno(_ sender: UIButton) {
        
        
        let _ = db.collection("alumno-taller").addDocument(data: [
            "codigoTaller": codigo!, "estatus": tfStatus.text!, "grupoId":grupoId!, "matricula":tfMatricula.text!, "periodo": tfPeriodo.text! ]) { error in
                if let error = error{ // Si hay error
                    print(error.localizedDescription)
                } else {
                    print("Datos guardados con éxito")
                    
                    let alerta = UIAlertController(title: "Listo", message: "Alumno inscrito correctamente", preferredStyle: .alert)
                    let accion = UIAlertAction(title: "Okay", style: .cancel)
                    alerta.addAction(accion)
                    self.present(alerta, animated: true)
                    self.tfMatricula.text = ""
                    self.tfStatus.text = ""
                    self.tfPeriodo.text = ""
                }
            }
    }
    
/*
    override func viewWillDisappear(_ animated: Bool) {
        
        var vistaIni : ViewControllerAlumnos!
        vistaIni.tlTexto.text = "hola"
    }
 */
     
     
    
    
}
