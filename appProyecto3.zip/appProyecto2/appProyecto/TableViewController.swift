//
//  TableViewController.swift
//  appProyecto
//
//  Created by Alessandro Tolentino Hernandez on 02/11/22.
//

import UIKit
import Firebase

class TableViewController: UITableViewController {
    
    
    var listaTalleres = [taller]()
    var db = Firestore.firestore()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
        
        getTalleres()
    }
    
    func getTalleres(){
        var arrTalleres = [taller]()
        
        db.collection("inscripcion").getDocuments { querySnapshot, error in
            if let error = error {
                print(error.localizedDescription)
            } else {
                for document in querySnapshot!.documents{
                    let data = document.data()
                    let ident = document.documentID
                    let calif = data["calif"] as! Int
                    let codigoTaller = data["codigoTaller"] as! String
                    let grupoID = data["grupoID"] as! Int
                    let periodo = data["periodo"] as! String
                    let status = data["status"] as! String
                    let campus = data["campus"] as! String
                    let titulo = data["tituloTaller"] as! String
                    let tetramestre = data["tetramestre"] as! Int
                    
                    let unTaller = taller(ident: ident, calif: calif, codeTaller: codigoTaller, grupoID: grupoID, periodo: periodo, status: status, campus: campus, titulo: titulo, tetramestre: tetramestre)
                    arrTalleres.append(unTaller)
                    
                }
                self.listaTalleres = arrTalleres
                self.tableView.reloadData()
            }
        }
    }
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return listaTalleres.count
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath) as! CustomTableViewCell
        
        // Configure the cell...
        cell.LbCodigoTaller.text = listaTalleres[indexPath.row].codeTaller
        cell.LbTituloTaller.text = listaTalleres[indexPath.row].titulo + " Gpo" + String (listaTalleres[indexPath.row].grupoID)
        cell.lbGrupo.text = ""
        cell.LbStatus.text = listaTalleres[indexPath.row].status
        if listaTalleres[indexPath.row].status == "Reprobado"{
            cell.LbStatus.textColor = UIColor(red: 233, green: 0, blue: 0, alpha: 1)
            cell.vista3.backgroundColor = UIColor(red: 197, green: 0, blue: 0, alpha: 1)
            cell.LbCalif.backgroundColor = UIColor(red: 197, green: 0, blue: 0, alpha: 40)
            
        } else if listaTalleres[indexPath.row].status == "Aprobado"{
            cell.LbStatus.textColor = UIColor(red: 0, green: 143, blue: 0, alpha: 1)
            cell.vista3.backgroundColor = UIColor(red: 0, green: 143, blue: 0, alpha: 1)
            cell.LbCalif.backgroundColor = UIColor(red: 0, green: 143, blue: 0, alpha: 40)
            
            
        } /*else if listaTalleres[indexPath.row].status == "Cursando"{
                cell.LbStatus.textColor = UIColor(red: 255, green: 152, blue: 0, alpha: 1)
                cell.vista3.backgroundColor = UIColor(red: 255, green: 147, blue: 0, alpha: 1)
                cell.LbCalif.backgroundColor = UIColor(red: 255, green: 147, blue: 0, alpha: 40)
            
        }
           */
        cell.LbCampus.text = listaTalleres[indexPath.row].campus
        cell.LbCalif.text = String(listaTalleres[indexPath.row].calif)
        cell.LbPerido.text = listaTalleres[indexPath.row].periodo
        
        return cell
    }
    
    
    /*
     // Override to support conditional editing of the table view.
     override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
     // Return false if you do not want the specified item to be editable.
     return true
     }
     */
    
    /*
     // Override to support editing the table view.
     override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
     if editingStyle == .delete {
     // Delete the row from the data source
     tableView.deleteRows(at: [indexPath], with: .fade)
     } else if editingStyle == .insert {
     // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
     }
     }
     */
    
    /*
     // Override to support rearranging the table view.
     override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {
     
     }
     */
    
    /*
     // Override to support conditional rearranging of the table view.
     override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
     // Return false if you do not want the item to be re-orderable.
     return true
     }
     */
    
    
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let vistaDet = segue.destination as! ViewControllerDetalle
        let indice = tableView.indexPathForSelectedRow!
        vistaDet.tallerAct = listaTalleres[indice.row]
    }


}
