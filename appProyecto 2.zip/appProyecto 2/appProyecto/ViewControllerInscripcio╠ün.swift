//
//  ViewControllerInscripción.swift
//  appProyecto
//
//  Created by Alessandro Tolentino Hernandez on 17/10/22.
//

import UIKit

class ViewControllerInscripcio_n: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    
    // MARK: - Navigation

    @IBAction func Back(_ sender: UIButton) {
        dismiss(animated: true)
    }
    
    @IBAction func finalizar(_ sender: UIButton) {
        let alerta = UIAlertController(title: "Confirmación", message: "Inscripción realizada con éxito", preferredStyle: .alert)
        let accion = UIAlertAction(title: "Okay", style: .cancel)
        alerta.addAction(accion)
        present(alerta, animated: true)
        
        
    }
}
