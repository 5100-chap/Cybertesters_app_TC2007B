//
//  ViewControllerTetramestre.swift
//  appProyecto
//
//  Created by Hugo Palomares on 09/11/22.
//

import UIKit
import Firebase

class ViewControllerTetramestre: UIViewController {
    
    @IBOutlet weak var a: UILabel!
    var listaTalleres = [taller]()
    var taller1: taller!

    var db = Firestore.firestore()
    let defaults = UserDefaults.standard
    var matricula: String!
//    var unTaller: taller!
    
    @IBOutlet weak var lbCodigoTaller: UILabel!
    @IBOutlet weak var lbNombreTaller: UILabel!    
    @IBOutlet weak var lbProfesor: UILabel!
    @IBOutlet weak var lbStatus: UILabel!
    @IBOutlet weak var lbCampus: UILabel!
    @IBOutlet weak var lbPeriodo: UILabel!
    @IBOutlet weak var lbCalif: UILabel!
    @IBOutlet weak var vista3: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        let taller1 = getTaller()
        getTaller()
        a.text = matricula
//        lbCodigoTaller.text = taller1.codeTaller
//        lbNombreTaller.text = "\(taller1.titulo) (Gpo \(taller1.grupoID))"
//        lbStatus.text = taller1.status
//        lbCampus.text = taller1.campus
//        lbPeriodo.text = taller1.periodo
//        lbCalif.text = "\(taller1.calif)"
        // Do any additional setup after loading the view.
    }
    
    func getTaller() {
        var arrTalleres = [taller]()
        var unTaller: taller!
        matricula = defaults.string(forKey: "matricula")
        db.collection("inscripcion").whereField("matricula", isEqualTo: matricula!).getDocuments() { QuerySnapshot, error in
            if let error = error{
                print(error.localizedDescription)

            }
            else {
                for document in QuerySnapshot!.documents{
                    let data = document.data()
                    let ident = document.documentID
                    let matricula = data["matricula"] as! String
                    let calif = data["calif"] as! Int
                    let codigoTaller = data["codigoTaller"] as! String
                    let grupoID = data["grupoID"] as! Int
                    let periodo = data["periodo"] as! String
                    let status = data["status"] as! String
                    let campus = data["campus"] as! String
                    let tituloTaller = data["tituloTaller"] as! String
                    let tetramestre = data["tetramestre"] as! Int
                    
                    
                    unTaller = taller(ident: ident, calif: calif, codeTaller: codigoTaller, grupoID: grupoID, periodo: periodo, status: status, campus: campus, titulo: tituloTaller, tetramestre: tetramestre)
                    
                    arrTalleres.append(unTaller)
                }
            }
            self.taller1 = unTaller
            self.listaTalleres = arrTalleres
            
            self.lbCodigoTaller.text = unTaller.codeTaller
            self.lbNombreTaller.text = "\(unTaller.titulo) (Gpo \(unTaller.grupoID))"
            self.lbStatus.text = unTaller.status
            self.lbCampus.text = "Campus: \(unTaller.campus)"
            self.lbPeriodo.text = unTaller.periodo
            self.lbCalif.text = "\(unTaller.calif)"
            
            
            if unTaller.status == "Reprobado"{
                self.lbStatus.textColor = UIColor(red: 233, green: 0, blue: 0, alpha: 1)
                self.vista3.backgroundColor = UIColor(red: 197, green: 0, blue: 0, alpha: 1)
                self.lbCalif.backgroundColor = UIColor(red: 197, green: 0, blue: 0, alpha: 40)
                
            } else if unTaller.status == "Aprobado"{
                self.lbStatus.textColor = UIColor(red: 0, green: 143, blue: 0, alpha: 1)
                self.vista3.backgroundColor = UIColor(red: 0, green: 143, blue: 0, alpha: 1)
                self.lbCalif.backgroundColor = UIColor(red: 0, green: 143, blue: 0, alpha: 40)
            }
        
        }
        
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
