//
//  taller.swift
//  appProyecto
//
//  Created by Alessandro Tolentino Hernandez on 02/11/22.
//

import UIKit

class taller: NSObject {

    
    var ident: String
    var calif: Int
    var codeTaller: String
    var grupoID: Int
    var periodo: String
    var status: String
    var campus: String
    var titulo: String
    
    init(ident: String, calif: Int, codeTaller: String, grupoID: Int, periodo: String, status: String, campus: String, titulo: String) {
        self.ident = ident
        self.calif = calif
        self.codeTaller = codeTaller
        self.grupoID = grupoID
        self.periodo = periodo
        self.status = status
        self.campus = campus
        self.titulo = titulo
    }

}
