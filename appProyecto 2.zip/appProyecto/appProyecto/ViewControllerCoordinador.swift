//
//  ViewControllerCoordinador.swift
//  appProyecto
//
//  Created by Alessandro Tolentino Hernandez on 07/11/22.
//

import UIKit
import Firebase

class ViewControllerCoordinador: UIViewController, UITableViewDelegate, UITableViewDataSource{
    
    var db = Firestore.firestore()
    let defaults = UserDefaults.standard
    var nomina: String?
    var campus: String?
    var listaTalleres = [tallerr]()
    
    @IBOutlet weak var tlCampus: UILabel!
    
    @IBOutlet weak var table: UITableView!
    
    @IBOutlet weak var tlNombre: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tlCampus.text = "Lista de talleres campus " + defaults.string(forKey: "campus")!

        getCoordinador()
        getTaller()
    }
    
    func getCoordinador(){
        nomina = defaults.string(forKey: "nomina")!
        
        db.collection("coordinador").whereField("nomina", isEqualTo: nomina!)
        .getDocuments() { QuerySnapshot, error in
            if let error = error{
                print(error.localizedDescription)

            } else {
                for document in QuerySnapshot!.documents{
                    let data = document.data()
                    
                    let nombre : String = data["nombre"] as! String
                    
                    self.tlNombre.text = "Coordinador: " + nombre
                }
            }
        }
    }
    
    
    
    func getTaller(){
        
        campus = defaults.string(forKey: "campus")!
        var arrTalleres = [tallerr]()
        
        db.collection("taller").whereField("campus", isEqualTo: campus!).getDocuments() { querySnapshot, error in
            if let error = error {
                print(error.localizedDescription)
            } else {
                for document in querySnapshot!.documents{
                    let data = document.data()
                    let ident = document.documentID
                    let descripcion = data["Description"] as! String
                    let codigoTaller = data["codigoTaller"] as! String
                    
                    let titulo = data["nombreTaller"] as! String
                    
                    print(titulo)
                    
                    let unTaller = tallerr(ident: ident, descripcion: descripcion, codigoTaller: codigoTaller, nombreTaller: titulo)
                    arrTalleres.append(unTaller)
                    
                }
                self.listaTalleres = arrTalleres
                self.table.reloadData()
                
            }
        }
        
    }
     
     
    
    //MARK: - Métodos de data source
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listaTalleres.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let celda = tableView.dequeueReusableCell(withIdentifier: "celda")!
        celda.textLabel?.text = listaTalleres[indexPath.row].codigoTaller
        celda.detailTextLabel?.text = listaTalleres[indexPath.row].nombreTaller
        
        return celda
    }
            
        
            
            
            
            
            
            
             // MARK: - Navigation
             
             // In a storyboard-based application, you will often want to do a little preparation before navigation
             override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
                 let vistaGrupos = segue.destination as! ViewControllerGrupo
                 let indice = table.indexPathForSelectedRow!
                 vistaGrupos.taller = listaTalleres[indice.row].nombreTaller
            
             }
             
            
        }
        
    
