//
//  ViewControllerCorreo.swift
//  appProyecto
//
//  Created by Alessandro Tolentino Hernandez on 17/10/22.
//

import UIKit
import Firebase

class ViewControllerCorreo: UIViewController {
    var db = Firestore.firestore()
    var band : Bool?
    var mat : String?

    
    let defaults = UserDefaults.standard
    
    @IBOutlet weak var tfCorreo: UITextField!
    
    @IBOutlet weak var tfContra: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    @IBAction func botonRegresar(_ sender: UIButton) {
        dismiss(animated: true)
    }
    
    func verificar (completion: @escaping(String) -> Void){
        db.collection("alumno").whereField("matricula", isEqualTo: tfCorreo.text)
            .whereField("password", isEqualTo: tfContra.text)
        
            .getDocuments() { (querySnapshot, err) in
                if let err = err {
                    print("Error getting documents: \(err)")
                } else {
                    if(querySnapshot!.documents.isEmpty){
                        completion("no")
                    
                    } else {
                        let data = querySnapshot!.documents[0].data()
                        
                        if  data["clave"] as! String == "Alumno"{
                            self.mat = data["matricula"] as! String
                            self.defaults.set(self.mat, forKey: "matricula")
                            completion("Alumno")
                        }
                        else if data["clave"] as! String == "Coordinador"{
                            self.defaults.set(data["matricula"] as! String, forKey: "nomina")
                            self.defaults.set(data["campus"] as! String, forKey: "campus")
                            
                            completion("Coordinador")
                        }

                    }
                }
        }
        
       
        
        
    }
    
    
    @IBAction func ini(_ sender: UIButton) {
        if tfCorreo.text == "" {
            let alerta = UIAlertController(title: "Error", message: "No se introdujo un correo/matricula", preferredStyle: .alert)
            let accion = UIAlertAction(title: "Okay", style: .cancel)
            alerta.addAction(accion)
            present(alerta, animated: true)
            

        } else if tfContra.text == ""{
            let alerta = UIAlertController(title: "Error", message: "No se introdujo una contraseña", preferredStyle: .alert)
            let accion = UIAlertAction(title: "Okay", style: .cancel)
            alerta.addAction(accion)
            present(alerta, animated: true)
            
        } else {
            verificar(){ tipo in
                
                if tipo == "no"{
                    let alerta = UIAlertController(title: "Error", message: "Correo o Contraseña invalido", preferredStyle: .alert)
                    let accion = UIAlertAction(title: "Okay", style: .cancel)
                    alerta.addAction(accion)
                    self.present(alerta, animated: true)
                    
                } else if tipo == "Alumno"{
                    DispatchQueue.main.async {
                        [unowned self] in
                        self.performSegue(withIdentifier: "siguiente", sender: self)
                    }

                } else if tipo == "Coordinador" {
                    DispatchQueue.main.async {
                        [unowned self] in
                        self.performSegue(withIdentifier: "coordinador", sender: self)
                    }
                    
                }
            }
            
            
            
        }
        
    }
    
    
    
    
    
/*
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        
        if identifier == "siguiente"{
            
            if tfCorreo.text == "" {
                let alerta = UIAlertController(title: "Error", message: "No se introdujo un correo/matricula", preferredStyle: .alert)
                let accion = UIAlertAction(title: "Okay", style: .cancel)
                alerta.addAction(accion)
                present(alerta, animated: true)
                return false
                
            } else {
                
                verificar(){ bandera in
                    
                    if bandera == true{
                        let alerta = UIAlertController(title: "Error", message: "No se encontró una cuenta registrada con la informacion proporcionada", preferredStyle: .alert)
                        let accion = UIAlertAction(title: "Okay", style: .cancel)
                                               alerta.addAction(accion)
                        self.present(alerta, animated: true)
                        
                    } else {
                        print("okay")
                        self.band = true
                        
                    }
                }
              
            }
            
            
        }
        if self.band == true{
            return true
        }
        
        return false
    }
    
    
*/
    
    
}
