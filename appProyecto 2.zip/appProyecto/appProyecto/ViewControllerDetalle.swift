//
//  ViewControllerDetalle.swift
//  appProyecto
//
//  Created by Alessandro Tolentino Hernandez on 03/11/22.
//

import UIKit

class ViewControllerDetalle: UIViewController {


    @IBOutlet weak var lbInfo: UILabel!
    
    @IBOutlet weak var lbTitulo: UILabel!
    
    
    @IBOutlet weak var lbStatus: UILabel!
    
    @IBOutlet weak var lbCampus: UILabel!
    
    @IBOutlet weak var txtDescrip: UITextView!
    
    @IBOutlet weak var lbCalif: UILabel!
    
    @IBOutlet weak var lbPeriodo: UILabel!
    
    var codigo : String!
    var tallerAct: taller!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    
        
        lbInfo.text = "Taller| Grupo " + String(tallerAct.grupoID) + " | " + tallerAct.codeTaller
        lbTitulo.text = tallerAct.titulo
        lbCampus.text = tallerAct.campus
        lbPeriodo.text = tallerAct.periodo + " 2022"
        lbStatus.text = tallerAct.status
        if tallerAct.status == "Reprobado"{
            lbStatus.textColor = UIColor(red: 233, green: 0, blue: 0, alpha: 1)
        }
        lbCalif.text = String(tallerAct.calif)
        
        
        
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
